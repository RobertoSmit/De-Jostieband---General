To learn more about the font family and its license, visit https://www.fontmirror.com/fancy-quisley

License: Free for personal use.
This is a preview font for testing, you can purchase its full version at https://crmrkt.com/vrWezx.Contact stringlabscreative@gmail.com for commercial use.
You can donate to the font author at https://paypal.me/stringlabs.
To learn more about the font, visit https://stringlabscreative.com/fancy-quisley/.