To learn more about the font family and its license, visit https://www.fontmirror.com/dutch-brigade

License: Free for personal use.
This is a preview font for testing, you can purchase its full version at https://typefactory.co/product/dutch-brigade-modern-blackletter-typeface/.